<?php
require_once 'db_connect.php';
include_once '../includes/funcao.php';
session_start();
if(isset($_POST['btn-cadastrar'])){
    $nome = clear($_POST['nNome']);
    $sobrenome = clear($_POST['nSobrenome']);
    $email = clear($_POST['nEmail']);
    $idade = clear($_POST['nIdade']);

    $sql = "INSERT INTO clientes (nome, sobrenome, email, idade) VALUES ('$nome', '$sobrenome', '$email', '$idade')";

    if(mysqli_query($connect, $sql)){
        $_SESSION['mensagem'] = "Cadastrado com sucesso!";
        header('Location: ../index.php');
    }else{
        $_SESSION['mensagem'] = "Erro ao cadastrar!";
        header('Location: ../index.php');
    }
}

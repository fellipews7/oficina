<?php
require_once 'db_connect.php';
include_once '../includes/funcao.php';

session_start();

if(isset($_POST['btn-deletar'])){

    $id = clear($_POST['nIdDeletar']);

    $sql = "DELETE FROM clientes WHERE id= '$id'";

    if(mysqli_query($connect, $sql)){
        $_SESSION['mensagem'] = "Deletado com sucesso!";
        header('Location: ../index.php');
    }else{
        $_SESSION['mensagem'] = "Erro ao deletar!";
        header('Location: ../index.php');
    }
}



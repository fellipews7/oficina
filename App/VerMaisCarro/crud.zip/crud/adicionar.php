<?php
include_once 'includes/header.php';
?>

    <div class="row">
        <div class="col s12 m6 push-m3 ">
            <h3 class="light">Novo cliente</h3>

            <form action="phpaction/create.php" method="post">
                <div class="input-field col s12">
                    <label for="iNome">Nome</label>
                    <input type="text" name="nNome" id="iNome">
                </div>

                <div class="input-field col s12">
                    <label for="iSobrenome">Sobrenome</label>
                    <input type="text" name="nSobrenome" id="iSobrenome">
                </div>

                <div class="input-field col s12">
                    <label for="iEmail">Email</label>
                    <input type="email" name="nEmail" id="iEmail">
                </div>

                <div class="input-field col s12">
                    <label for="iIdade">idade</label>
                    <input type="text" name="nIdade" id="iIdade">
                </div>

                <button type="submit" name="btn-cadastrar" class="btn">Cadastrar</button>
                <a href="index.php" class="btn green">Lista de clientes</a>
            </form>
        </div>
    </div>

<?php
include_once 'includes/footer.php';
?>


